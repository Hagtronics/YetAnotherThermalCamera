/* YATC - Yet Another Thermal Camera Project 
 * 
 * Written By: Steven C. Hageman 12/2018
 *
 * Released under the: "Do whatever you want with it" license.
 * 
 * Remember the code was written by a raving lunatic and is therefore
 * certain to contain deadly bugs, errors and omissions. 
 * USE AT YOUR OWN RISK - You have been warned.
 *
 * Portions may be copyrighted by other individuals or entities.
 * See each specific code file for that information.
 * 
 * G'Day.....
 *
 */



//=====[ Image Processing ]=====================================================

#include "app.h"


// For use on the 0-255 limited image
float Brightness = 0.0f;  
float Contrast = 4.0f;


// Expand High End
const uint8_t HighEndContrastCurve[] = {
0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 
13, 13, 14, 14, 15, 15, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22, 
23, 23, 24, 24, 25, 25, 26, 26, 27, 27, 28, 28, 29, 29, 30, 30, 31, 31, 32, 32, 
33, 33, 34, 34, 35, 35, 36, 36, 37, 37, 38, 38, 39, 39, 40, 40, 41, 41, 42, 42, 
43, 43, 44, 44, 45, 45, 46, 46, 47, 47, 48, 48, 49, 49, 50, 50, 51, 51, 52, 52, 
53, 53, 54, 54, 55, 55, 56, 56, 57, 57, 58, 58, 59, 59, 60, 60, 61, 61, 62, 62, 
63, 63, 64, 64, 65, 65, 66, 66, 67, 67, 68, 68, 69, 69, 70, 70, 71, 71, 72, 72, 
73, 73, 74, 74, 75, 75, 76, 76, 77, 77, 78, 78, 79, 79, 80, 80, 81, 81, 82, 82, 
83, 83, 84, 84, 85, 85, 87, 89, 91, 93, 95, 97, 99, 101, 103, 105, 107, 109, 111, 
113, 115, 117, 119, 121, 123, 125, 127, 129, 131, 133, 135, 137, 139, 141, 143, 
145, 147, 149, 151, 153, 155, 157, 159, 161, 163, 165, 167, 169, 171, 173, 175, 
177, 179, 181, 183, 185, 187, 189, 191, 193, 195, 197, 199, 201, 203, 205, 207, 
209, 211, 213, 215, 217, 219, 221, 223, 225, 227, 229, 231, 233, 235, 237, 239, 
241, 243, 245, 247, 249, 251, 253, 255
};


// Expand Low End
const uint8_t LowEndContrastCurve[] = {
0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 
46, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 88, 
90, 92, 94, 96, 98, 100, 102, 104, 106, 108, 110, 112, 114, 116, 118, 120, 122, 124, 
126, 128, 130, 132, 134, 136, 138, 140, 142, 144, 146, 148, 150, 152, 154, 156, 158, 
160, 162, 164, 166, 168, 170, 170, 171, 171, 172, 172, 173, 173, 174, 174, 175, 175, 
176, 176, 177, 177, 178, 178, 179, 179, 180, 180, 181, 181, 182, 182, 183, 183, 184, 
184, 185, 185, 186, 186, 187, 187, 188, 188, 189, 189, 190, 190, 191, 191, 192, 192, 
193, 193, 194, 194, 195, 195, 196, 196, 197, 197, 198, 198, 199, 199, 200, 200, 201, 
201, 202, 202, 203, 203, 204, 204, 205, 205, 206, 206, 207, 207, 208, 208, 209, 209, 
210, 210, 211, 211, 212, 212, 213, 213, 214, 214, 215, 215, 216, 216, 217, 217, 218, 
218, 219, 219, 220, 220, 221, 221, 222, 222, 223, 223, 224, 224, 225, 225, 226, 226, 
227, 227, 228, 228, 229, 229, 230, 230, 231, 231, 232, 232, 233, 233, 234, 234, 235, 
235, 236, 236, 237, 237, 238, 238, 239, 239, 240, 240, 241, 241, 242, 242, 243, 243, 
244, 244, 245, 245, 246, 246, 247, 247, 248, 248, 249, 249, 250, 250, 251, 251, 252, 
252, 253, 253, 254, 254, 255
};


// ===== Histogram Expansion =================================================

// This will do a histogram expansion to a range of 0-255 
void ApplyExpansion()
{
    int row, col; 
    
    // Figure whole image average contrast to expand image to 0-255 range
    Contrast = 255.0 / (float)(AvgMaxValue - AvgMinValue);
 
    for(row = 0 ; row < 116 ; row++)
    {
        for(col = 0 ; col < 156 ; col ++)
        { 
            // Add adjustments
            float result = Pout[row][col] - AvgMinValue;
            result = result * Contrast;
            
            // Full scale range is 0-255 here
            int16_t resultInt = (int16_t)(result + 0.5);
            
            // Bound the values
            if( resultInt < 0 )
                resultInt = 0;
            
            if( resultInt > 255 )
                resultInt = 255;
            
            Pout[row][col] = resultInt;
        }
    }
    
}

void DoBrightnessAdjustment()
{
    int row, col; 
    
    for(row = 0 ; row < 116 ; row++)
    {
        for(col = 0 ; col < 156 ; col ++)
        { 
            // Add adjustments
            float result = Pout[row][col];
            result = result + Brightness;
            
            int16_t resultInt = (int16_t)(result + 0.5);
            
            // Bound the values
            if( resultInt < 0 )
                resultInt = 0;
            
            if( resultInt > 255 )
                resultInt = 255;
            
            Pout[row][col] = resultInt;
        }
    }
}


// Adds a contrast curve if requested
void ApplyContrastCurve()
{
    int row, col; 
    
    // No Contrast
    if(ContrastCurve == NORMAL)
        return;
    
    for(row = 0 ; row < 116 ; row++)
    {
        for(col = 0 ; col < 156 ; col ++)
        { 
            
            // Add adjustments
            int16_t input = Pout[row][col];
            
            // Select Contrast
            if(ContrastCurve == HIGH_END)
            {
                Pout[row][col] = HighEndContrastCurve[input];
            }
            else // Must be high end contrast
            {
                Pout[row][col] = LowEndContrastCurve[input];
            }
        }
    }
}




static bool touched = false;

static int16_t initialX = 0;
static int16_t lastDelta = -5000;
//static int16_t initialY = 0;


// Code to get and manipulate Brightness and Contrast values
// Remember that X&Y are reversed due to the landscape display orientation
void GetImageAdjustments()
{
    // Defaults to get this running
    // Brightness = 0.0;
    // Contrast = 2.0;
    
    if(IsTouchHit())
    {
        if(touched == false)
        {
            initialX = Touch_Get_X();
            touched = true;
        }
        
        if(touched == true)
        {
            // Is it center of the screen?
            // If so then reset the Brightness to zero
            // Set Contrast Curve to Normal
            int16_t touchX = Touch_Get_X();
            int16_t touchY = Touch_Get_Y();
            if(touchX < 160)
            {
                if(touchX > 100)
                {
                    if(touchY < 180)
                    {
                        if(touchY > 140)
                        {
                            //Bingo! - User hit the center of the screen!
                            Brightness = 0.0f;
                            Contrast = NORMAL;
                            return;
                        }
                    }
                }
            }
                
            // Is it at right 3rd of screen?
            // If so then it is a contrast adjustment
            if(touchY > 170)
            {
                // Set it to normal, then override if needed
                ContrastCurve = NORMAL;
                if(touchX > 170)
                {
                    // Set Contrast to High End
                    ContrastCurve = HIGH_END;              
                }
                if(touchX < 85)
                {
                    // Set Contrast to Low End
                    ContrastCurve = LOW_END;     
                }
            }
            
            // If on Left 3rd of screen then a brightness touch
            if(touchY < 85)
            {
                // Get delta /adjust brightness / bound if needed
                int16_t delta = (int16_t)Touch_Get_X() - (int16_t)initialX;
                if(delta != lastDelta)
                {
                    Brightness += (float)delta / 8.0f;

                    lastDelta = delta;

                    if(Brightness > 400.0f)
                        Brightness = 400.0f;
                    if(Brightness < -400.0f)
                        Brightness = -400.0f;
                }
            }
        }
    }
    else
    {
        // Not touched now - so restart;
        touched = false;
    }
}
