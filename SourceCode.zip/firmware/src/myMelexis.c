/* YATC - Yet Another Thermal Camera Project 
 * 
 * Written By: Steven C. Hageman 12/2018
 *
 * Released under the: "Do whatever you want with it" license.
 * 
 * Remember the code was written by a raving lunatic and is therefore
 * certain to contain deadly bugs, errors and omissions. 
 * USE AT YOUR OWN RISK - You have been warned.
 *
 * Portions may be copyrighted by other individuals or entities.
 * See each specific code file for that information.
 * 
 * G'Day.....
 *
 */

#include "app.h"

// Multiplication factor to scale float temperature to int16_t's by
#define SCALE_FACTOR 100


/*=========================================================================*/
// Proper rounding function
static int16_t fround(float number)
{
    return (number >= 0) ? (int16_t)(number + 0.5) : (int16_t)(number - 0.5);
}


//=====[ Local Functions ]======================================================

void AveragingReset(float Ta)
{
    int16_t val = (int16_t)(Ta * SCALE_FACTOR);
    AvgMaxValue = val;     // Temp*10
    AvgMinValue = val;     
    AvgCenValue = val;
}

void MinMovingAverage(int16_t newVal)
{
    //AvgMinValue = (newVal >> 1) + (AvgMinValue >> 1);
    AvgMinValue = (newVal >> 2) + ((AvgMinValue >> 2) * 3);
}

void MaxMovingAverage(int16_t newVal)
{
    //AvgMaxValue = (newVal >> 1) + ((AvgMaxValue) >> 1);
    AvgMaxValue = (newVal >> 2) + (((AvgMaxValue) >> 2) * 3);
}

void CenMovingAverage(int16_t newVal)
{
    //AvgCenValue = (newVal >> 1) + ((AvgCenValue) >> 1);
    AvgCenValue = (newVal >> 2) + (((AvgCenValue) >> 2) * 3);
}


// Convert to the Pin array from floats to (int16 * SCALE_FACTOR) for 0.01 deg resolution
// Find Min and Max while we are at it.
// Also reverse the horizontal pixels so they display properly
void ConvertDataArray()
{  
    int16_t max = -32000;
    int16_t min =  32000;
   
    int32_t row, col;
    for(row = 0 ; row < 24 ; row++)
    {
        for(col = 0 ; col < 32 ; col++)
        {
            //                                        (31-col) reverses the display
            float tempF = PixelTempArray[(row * 32) + (31-col)];
            
            if(tempF > 320.0)
                tempF = 320.0;
            
            if(tempF < -320.0)
                tempF = -320.0;
            
            int16_t temp = fround(tempF * (float)SCALE_FACTOR);
            Pin[row][col] = temp;

            if(temp > max)
                max = temp;
            
            if(temp < min)
                min = temp;
        }
    }  
    
    // Update the average values
    MinMovingAverage(min);
    MaxMovingAverage(max);
    CenMovingAverage(Pin[11][15]);
}


void Melexis_Init()
{
    DelayMs(80); // Required startup delay
}




//==========================================================================

// Test code below
//void ShowFrameData()
//{
//    // Try to determine frame
//    
//    // Should set the frame rate really slow for this, just to test
//    
//    while(1)
//    {
//        InterlaceF0();
//        DelayMs(100);
//    }
//    
//    
//    while(1)
//    {
//        int16_t frame = MLX90640_GetFrameData(0x33, mlx90640Frame);
//    
//        if(frame == 0)
//        {
//            LCD_Cls();
//            LCD_Print("Frame 0");
//            DelayMs(500);
//        }
//
//        if(frame == 1)
//        {
//            LCD_Cls();
//            LCD_Print("Frame 1");
//            DelayMs(500);
//        }
//    
//    }
//    
//}


