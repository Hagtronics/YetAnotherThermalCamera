/* YATC - Yet Another Thermal Camera Project 
 * 
 * Written By: Steven C. Hageman 12/2018
 *
 * Released under the: "Do whatever you want with it" license.
 * 
 * Remember the code was written by a raving lunatic and is therefore
 * certain to contain deadly bugs, errors and omissions. 
 * USE AT YOUR OWN RISK - You have been warned.
 *
 * Portions may be copyrighted by other individuals or entities.
 * See each specific code file for that information.
 * 
 * G'Day.....
 *
 */




// ===== BiLinear Interpolation =====

// ===== Melexis Version =====


#include "app.h"

// Zero output array
static void PoutInit()
{
    int32_t row, col;
    for(row = 0 ; row < 116 ; row++)
    {
        for(col = 0 ; col < 156 ; col++)
        {
            Pout[row][col] = -3000; // That's very cold!
        }
    }
}


// Proper rounding function
static int16_t fround(float number)
{
    return (number >= 0) ? (int16_t)(number + 0.5) : (int16_t)(number - 0.5);
}


static float InterpolatePoint(float v1, float v2, float between)
{
    return( v1 + (v2 - v1) * between);
}


// Adds 5 values between samples
//  x = 1,2,3,4 because you know values 0 and 5.
static int16_t Interpolate(int16_t firstVal, int16_t secondVal, int32_t x) 
{
    float rval=0.0;
    
    float v1 = firstVal;
    float v2 = secondVal;
    
    switch(x)
    {
        case 0: rval = v1; break;  
        case 1: rval = InterpolatePoint(v1, v2, 0.2); break;
        case 2: rval = InterpolatePoint(v1, v2, 0.4); break;
        case 3: rval = InterpolatePoint(v1, v2, 0.6); break;
        case 4: rval = InterpolatePoint(v1, v2, 0.8); break;
        case 5: rval = v2; break;
        default: rval = 0.0;
    }
    
    return(fround(rval));
}



//int16_t Pin[24][36];        // Pixel Array In
//int16_t Pout[116][156];     // Pixel Array Out (interpolated))

// Mapping function
void BiLinInterpolate()
{
    // *** Init the output array to really small values
    PoutInit();
    
    
    // *** Interpolate all known rows
    
    int32_t row,col; // row,col are input row and col
    
    int32_t rowNew = 0; 
    int32_t colNew=0;
    
    for(row = 0 ; row < 24 ; row++)
    {
        for(col = 0 ; col < 31 ; col++)
        {
            // Col 0 = known
            Pout[rowNew][colNew+0] = Pin[row][col];
            
            // Col1
            Pout[rowNew][colNew+1] = Interpolate( Pin[row][col], Pin[row][col+1], 1);
            
            // Col2
            Pout[rowNew][colNew+2] = Interpolate( Pin[row][col], Pin[row][col+1], 2);
            
            // Col3
            Pout[rowNew][colNew+3] = Interpolate( Pin[row][col], Pin[row][col+1], 3);
            
            // Col4
            Pout[rowNew][colNew+4] = Interpolate( Pin[row][col], Pin[row][col+1], 4);
            
            // Col5 = known
            Pout[rowNew][colNew+5] = Pin[row][col+1];       
            
            colNew += 5;
        }
        
        colNew = 0;
        rowNew += 5;
    } // All known rows interpolated now
    

    
    // *** Interpolate all the columns, since all the new rows are known (by 5's)
    for(rowNew = 0 ; rowNew < 115 ; rowNew += 5)
    {
        for(colNew = 0 ; colNew < 156 ; colNew++)
        {
            // Row 0
            Pout[rowNew + 0][colNew] = Interpolate( Pout[rowNew][colNew], Pout[rowNew + 5][colNew], 0 );
            
            // Row 1
            Pout[rowNew + 1][colNew] = Interpolate( Pout[rowNew][colNew], Pout[rowNew + 5][colNew], 1 );
            
            // Row 2
            Pout[rowNew + 2][colNew] = Interpolate( Pout[rowNew][colNew], Pout[rowNew + 5][colNew], 2 );
            
            // Row 3
            Pout[rowNew + 3][colNew] = Interpolate( Pout[rowNew][colNew], Pout[rowNew + 5][colNew], 3 );
            
            // Row 4
            Pout[rowNew + 4][colNew] = Interpolate( Pout[rowNew][colNew], Pout[rowNew + 5][colNew], 4 );
            
            // Row 5
            Pout[rowNew + 5][colNew] = Interpolate( Pout[rowNew][colNew], Pout[rowNew + 5][colNew], 5 );
        }
    }  
}

// End
