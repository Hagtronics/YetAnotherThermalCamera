/* YATC - Yet Another Thermal Camera Project 
 * 
 * Written By: Steven C. Hageman 12/2018
 *
 * Released under the: "Do whatever you want with it" license.
 * 
 * Remember the code was written by a raving lunatic and is therefore
 * certain to contain deadly bugs, errors and omissions. 
 * USE AT YOUR OWN RISK - You have been warned.
 *
 * Portions may be copyrighted by other individuals or entities.
 * See each specific code file for that information.
 * 
 * G'Day.....
 *
 */
 

#include "app.h"
//#include <proc/p32mz2048efh064.h>


static void SplashScreen()
{
    // Print Hello Screen / You can change to whatever you want
    // Or remove it completely.
    tft_setCursor(15,100);
    tft_setTextSize(5);
    tft_setTextColor(0xA051);
    tft_writeString("H");DelayMs(5);
    tft_writeString("e");DelayMs(5);
    tft_writeString("l");DelayMs(5);
    tft_writeString("l");DelayMs(5);
    tft_writeString("o");DelayMs(5);
    tft_writeString(".");DelayMs(5);
    tft_writeString(".");DelayMs(5);
    tft_writeString(".");DelayMs(5);
    tft_writeString(".");DelayMs(5);
    tft_writeString(".");DelayMs(5);
    
    
    
    tft_setCursor(11,96);
    tft_setTextSize(5);
    tft_setTextColor(0xFEE8);
    tft_writeString("H");DelayMs(25);
    tft_writeString("e");DelayMs(25);
    tft_writeString("l");DelayMs(25);
    tft_writeString("l");DelayMs(25);
    tft_writeString("o");DelayMs(25);
    tft_writeString(".");DelayMs(25);
    tft_writeString(".");DelayMs(25);
    tft_writeString(".");DelayMs(25);
    tft_writeString(".");DelayMs(25);
    tft_writeString(".");DelayMs(25);
    
}



void APP_Initialize ( void )
{   
    LED_1_OFF();
    LED_2_OFF();
    
    DelayInit(); 
    
    I2C1_Init(100000);
    
    I2C2_Init(400000);
 
    LCD_Init();
    
    SplashScreen();
}



// This is ter Big Loop Starting point
void APP_Tasks ( void )
{
    int status; 
    
    // Speed 100k for setup
    I2C1_Init(100000);
  
    //Set refresh rate
    //A rate of 0.5Hz takes 4Sec per reading because we have to read two frames to get complete picture
    //MLX90640_SetRefreshRate(MLX90640_address, 0x00); //Set rate to 0.25Hz effective
    //MLX90640_SetRefreshRate(MLX90640_address, 0x01); //Set rate to 0.5Hz effective
    //MLX90640_SetRefreshRate(MLX90640_address, 0x02); //Set rate to 1Hz effective
    //MLX90640_SetRefreshRate(MLX90640_address, 0x03); //Set rate to 2Hz effective
    MLX90640_SetRefreshRate(MLX90640_address, 0x04); //Set rate to 4Hz effective - Works
    //MLX90640_SetRefreshRate(MLX90640_address, 0x05); //Set rate to 8Hz effective
    //MLX90640_SetRefreshRate(MLX90640_address, 0x06); //Set rate to 16Hz effective
    //MLX90640_SetRefreshRate(MLX90640_address, 0x07); //Set rate to 32Hz effective
    
    tft_setCursor(100,0);
    
    status = MLX90640_DumpEE (MLX90640_address, eeMLX90640); 
    //if(status != 0)
    //    LCD_PrintLn("Error = DumpEE");
    
    status = MLX90640_ExtractParameters(eeMLX90640, &mlx90640); 
    //if(status != 0)
    //    LCD_PrintLn("Error = MExtract");
    
    // Speed up I2C now to max speed
    I2C1_Init(1000000);
    status = MLX90640_GetFrameData(0x33, mlx90640Frame);    

    float mlxTa = MLX90640_GetTa(mlx90640Frame, &mlx90640); //Ta = 27.18 

    // Reset the averaging to Ta as a starting point
    AveragingReset(mlxTa);
    float emissivity = 0.95; 
    float tr; 
    int32_t lastFrame = 1; 
    
    
    // =====[ Interlace Reading Loop ]=====
    while(1)
    {
        int32_t frame = MLX90640_GetFrameData(0x33, mlx90640Frame);
        
        if(frame != lastFrame)
        {
            // On each new frame
            mlxTa = MLX90640_GetTa (mlx90640Frame, &mlx90640);  // Calculate Ta
            tr = mlxTa - 8.0; // Calculate average air loss
            MLX90640_CalculateTo(mlx90640Frame, &mlx90640, emissivity, tr, PixelTempArray);
            MLX90640_BadPixelsCorrection((&mlx90640)->brokenPixels, PixelTempArray, 1, &mlx90640); 
            
            // Process image in steps
            ConvertDataArray();         // Converts display to fixed point data
            BiLinInterpolate();         // Interpolate to 160 x 120 data array
            GetImageAdjustments();      // Check the touch input for any user requested changes
            ApplyExpansion();           // Apply Histogram expansion and convert 0-255 range
            ApplyContrastCurve();       // Apply the contrast curve
            DoBrightnessAdjustment();   // Add any additional brightness after contrast
            
            // Display proper Interlace frame
            if(frame == 0)
            {
                InterlaceF0();
            }
            else
            {
                InterlaceF1();
            }
            
            lastFrame = frame;
        }
        
        CheckPushButton();
        CheckPowerOffTimeout();
    }
    
}
        
// End
