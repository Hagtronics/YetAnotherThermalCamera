/* YATC - Yet Another Thermal Camera Project 
 * 
 * Written By: Steven C. Hageman 12/2018
 *
 * Released under the: "Do whatever you want with it" license.
 * 
 * Remember the code was written by a raving lunatic and is therefore
 * certain to contain deadly bugs, errors and omissions. 
 * USE AT YOUR OWN RISK - You have been warned.
 *
 * Portions may be copyrighted by other individuals or entities.
 * See each specific code file for that information.
 * 
 * G'Day.....
 *
 */



// User Interface Driver


#include "app.h"


// The heart of the timer delays - reads the core times (forced inline)
static inline uint32_t __attribute__((always_inline)) ReadCoreTimer()
{
    volatile uint32_t timer;

    // place the core_timer register value in timer
    asm volatile("mfc0   %0, $9" : "=r"(timer));

    return(timer);
}


// Power controller
bool IsPbHit()
{
    if(!PLIB_PORTS_PinGet(PORTS_ID_0,PORT_CHANNEL_C, PORTS_BIT_POS_13))
    {
        // Now wait till it is released
       while(!PLIB_PORTS_PinGet(PORTS_ID_0,PORT_CHANNEL_C, PORTS_BIT_POS_13))
       {
           _nop();
       }
       
       RestartTimeout();
       return true;
    }
    else
    {
        return false;
    }
}



// Touch screen
bool IsTouchHit()
{
    if(Touch_touched() > 0)
    {
        RestartTimeout();
        return true;
    }
    else
        return false;
}



// Timeout turnoff function

#define TIMEOUT_SECONDS 180  // 180 / 60 = 3 minutes

static uint32_t startCount;
static uint32_t secondsOn;
static uint32_t oneSecondCount;
static bool isFirstLoop = true;

void CheckPowerOffTimeout()
{
    if(isFirstLoop)
    {
        startCount = ReadCoreTimer();
        oneSecondCount = SYS_CLK_SystemFrequencyGet() / 2;
        secondsOn = 0;
        isFirstLoop = false;
    }
    
    uint32_t currentCount = ReadCoreTimer() - startCount;
    if(currentCount > oneSecondCount)
    {
        // That would be one second
        startCount = ReadCoreTimer();
        secondsOn++;
    }
   
    if(secondsOn > TIMEOUT_SECONDS)
    {
        // Kill power
        while(1)
        {
            KILL_POWER();
        }
    }
}


void RestartTimeout()
{
    secondsOn = 0;
}


void CheckPushButton()
{
    if(IsPbHit())
    {
        ColorMapToUse++;
        if(ColorMapToUse > 2)
            ColorMapToUse = 0;
    }
}
