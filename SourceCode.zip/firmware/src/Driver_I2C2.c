/* YATC - Yet Another Thermal Camera Project 
 * 
 * Written By: Steven C. Hageman 12/2018
 *
 * Released under the: "Do whatever you want with it" license.
 * 
 * Remember the code was written by a raving lunatic and is therefore
 * certain to contain deadly bugs, errors and omissions. 
 * USE AT YOUR OWN RISK - You have been warned.
 *
 * Portions may be copyrighted by other individuals or entities.
 * See each specific code file for that information.
 * 
 * G'Day.....
 *
 */



// Wired to TouchScreen / EEPROM / 400 kHz operation




#include "App.h"

#include "peripheral/ports/plib_ports.h"


//=====[ Define I2C Pins ]======================================================
// Be sure to set the pins as 'Digital' & 'Open Drain' in the pin configuration
// Pins should be selected on the 'natural' I2C ports or with 5V tolerant Pins
// Pins will be set Open Drain in the Init Procedure
#define _SCL2_port   PORT_CHANNEL_B
#define _SCL2_pin    PORTS_BIT_POS_15

#define _SDA2_port   PORT_CHANNEL_C
#define _SDA2_pin    PORTS_BIT_POS_15




//=====[ Define I2C Clock (in core cycles) ]===================================

// Hand optimized for 252 MHz and optimization -01
// 400 kHz timing delays

static uint32_t _I2C_CLOCK_CYCLES_H = 10;   // 1.3 uS
static uint32_t _I2C_CLOCK_CYCLES_L = 10;   // 1.3 uS
//static uint32_t _I2C_900NS_CYCLES = 9;      // 900nS
static uint32_t _I2C_600NS_CYCLES = 6;      // 600nS
static uint32_t _I2C_200NS_CYCLES = 2;      // 200nS



//=====[ Public Interface Routines ]=============================================================
//void I2C2_Init(400000);
//void I2C2_Init_Start();
//void I2C2_Init_RepeatStart();
//bool I2C2_Idle_Idle();
//bool I2C2_Idle_Idle_Write(uint8_t data);
//uint8_t I2C2_Idle_Idle_Read(bool sendAck);  // Send ACK if ack = true, otherwise send NACK
//void StopI2C2();


//=====[ Private routines ]=====================================================
// Local round closest
// Rounds integer division to the closest value
// This version only works for uints
static uint32_t divRoundClosest(uint32_t num, uint32_t denom)
{
  return ((num + (denom / 2)) / denom);
}


static bool ShiftLeft8(uint8_t *address, bool shift_in)
{
	bool bit_out;
	bit_out = (*address & 0x80)? 1:0;
	*address = *address << 1;
	*address = *address + (shift_in & 0x1);
	return(bit_out);
}

//=====[ Public Interface ]=====================================================


// Inits the I2C pins (If not done so already) and the clock speed.
// Max clock speed = 400000 Hz.
// Should only need to call this once.
// 
void I2C2_Init(uint32_t clock_Hz)
{
    
   
    PLIB_PORTS_ExistsPortsOpenDrain(PORTS_ID_0);
    
    
    // In case this hasn't been done.
    // Location: myPic32Lib_Universal.c
    //DelayInit();
    
    // Bound clock
    if(clock_Hz > 400000)
        clock_Hz = 400000;
    
    // Adjust the clock timing constants for a lower clock if requested
    _I2C_CLOCK_CYCLES_H = _I2C_CLOCK_CYCLES_H * divRoundClosest(400000, clock_Hz);
    _I2C_CLOCK_CYCLES_L = _I2C_CLOCK_CYCLES_L * divRoundClosest(400000, clock_Hz);
    
    // Float both SCL/SDA
    PLIB_PORTS_PinOpenDrainEnable(PORTS_ID_0, _SCL2_port, _SCL2_pin);
    PLIB_PORTS_PinOpenDrainEnable(PORTS_ID_0, _SDA2_port, _SDA2_pin);    
    _nop();
    
    PLIB_PORTS_PinSet(PORTS_ID_0, _SCL2_port, _SCL2_pin);
    PLIB_PORTS_PinSet(PORTS_ID_0, _SDA2_port, _SDA2_pin);   
    
    // Wait for lines to float high (If not already)
    DelayNs100(_I2C_CLOCK_CYCLES_H);
}

// Checks if bus is idle
// Returns true if Bus is idle.
bool I2C2_Idle()
{
    // Wait for lines to float high (If not already)
    DelayNs100(_I2C_600NS_CYCLES);
    
    //Both SCL/SDA must be open collector high.
    bool statSCL = PLIB_PORTS_PinGet(PORTS_ID_0, _SCL2_port, _SCL2_pin);
    bool statSDA = PLIB_PORTS_PinGet(PORTS_ID_0, _SDA2_port, _SDA2_pin);    
    
    if((statSDA == true) && (statSCL == true))
        return true;
    else
        return false;
}

// Issues a bus Start command.
void I2C2_Start()
{
    // At the start, both SCL and SDA are high
    // SDA then goes low
    PLIB_PORTS_PinSet(PORTS_ID_0, _SCL2_port, _SCL2_pin);
    PLIB_PORTS_PinSet(PORTS_ID_0, _SDA2_port, _SDA2_pin);  
    DelayNs100(_I2C_CLOCK_CYCLES_H);
    PLIB_PORTS_PinClear(PORTS_ID_0, _SDA2_port, _SDA2_pin);  
    DelayNs100(_I2C_CLOCK_CYCLES_H);
}

// Issues a bus Repeat Start command.
void I2C2_RepeatStart()
{
    // For a 'RepeatStart' the SDA & SCL lines are high.
    // The SDA line will go low.
    PLIB_PORTS_PinSet(PORTS_ID_0, _SDA2_port, _SDA2_pin);  
    DelayNs100(_I2C_CLOCK_CYCLES_H);
    PLIB_PORTS_PinSet(PORTS_ID_0, _SCL2_port, _SCL2_pin);
    DelayNs100(_I2C_CLOCK_CYCLES_H);
    PLIB_PORTS_PinClear(PORTS_ID_0, _SDA2_port, _SDA2_pin);  
    DelayNs100(_I2C_CLOCK_CYCLES_H);
}


// Issues a bus Stop command.
void I2C2_Stop()
{
    // SCL is high, then SDA goes high
    PLIB_PORTS_PinClear(PORTS_ID_0, _SDA2_port, _SDA2_pin);
    DelayNs100(_I2C_CLOCK_CYCLES_H);
    PLIB_PORTS_PinSet(PORTS_ID_0, _SCL2_port, _SCL2_pin);
    DelayNs100(_I2C_CLOCK_CYCLES_H);
    
    PLIB_PORTS_PinSet(PORTS_ID_0, _SDA2_port, _SDA2_pin);  
    DelayNs100(_I2C_CLOCK_CYCLES_H);
}


// Writes 8 bits to I2C bus
// Checks for 9th clock ACK - Returns ACK state false = ACK'd, false means no errors.
// Does not hang on no ACK, just keeps going.
// Leaves SCL low
bool I2C2_Write(uint8_t data)
{
    bool bit;
    int32_t i;
    
    // Start with Clock Low
    PLIB_PORTS_PinClear(PORTS_ID_0, _SCL2_port, _SCL2_pin);
    DelayNs100(_I2C_CLOCK_CYCLES_L);
    
    // Write out 8 bits
    for(i=0 ; i < 8 ; i++)
    {
        bit = ShiftLeft8(&data, false);
        if(bit)
            PLIB_PORTS_PinSet(PORTS_ID_0, _SDA2_port, _SDA2_pin);  
        else
            PLIB_PORTS_PinClear(PORTS_ID_0, _SDA2_port, _SDA2_pin);  
        
        DelayNs100(_I2C_200NS_CYCLES);
        
        // Clock - High, then Low.
        PLIB_PORTS_PinSet(PORTS_ID_0, _SCL2_port, _SCL2_pin);  
        DelayNs100(_I2C_CLOCK_CYCLES_H);
        
        PLIB_PORTS_PinClear(PORTS_ID_0, _SCL2_port, _SCL2_pin);  
        DelayNs100(_I2C_CLOCK_CYCLES_L);
    }
    
    // Let SDA float for ACK or NACK
    PLIB_PORTS_PinSet(PORTS_ID_0, _SDA2_port, _SDA2_pin);  
    DelayNs100(_I2C_200NS_CYCLES);
    
    // Send 09th clock - high
    PLIB_PORTS_PinSet(PORTS_ID_0, _SCL2_port, _SCL2_pin);  
    
    // Check for ACK = SDA Low - Don't wait forever
    DelayNs100(_I2C_CLOCK_CYCLES_H);
    bool statusACK = PLIB_PORTS_PinGet(PORTS_ID_0, _SDA2_port, _SDA2_pin);
        
    
    // Send 09th clock - low
    PLIB_PORTS_PinClear(PORTS_ID_0, _SCL2_port, _SCL2_pin);  
    DelayNs100(_I2C_CLOCK_CYCLES_L);
    
    // Return ACK or not.
    return statusACK;
}


// Reads the next byte from the I2C device
// Send ACK if sendACK is 'true', else send NACK if 'false'.
// Normally if subsequent reads will be dons - Send an ACK.
// After the last read, send a NACK then send the Stop.
uint8_t I2C2_Read(bool sendACK)
{
    uint8_t val = 0;
    bool state;
    int32_t i;
    
    // SDA must be set high for a read
    PLIB_PORTS_PinSet(PORTS_ID_0, _SCL2_port, _SCL2_pin);  
    
    // Read in 8 bits
    for(i=0 ; i<8 ;i++)
    {
        // Clock high
        PLIB_PORTS_PinSet(PORTS_ID_0, _SCL2_port, _SCL2_pin);  
        DelayNs100(_I2C_CLOCK_CYCLES_H);
        
        // Read SDA pin
//        bool state = PLIB_PORTS_PinGet(PORTS_ID_0, _SDA2_port, _SDA1_pin);
//        
//        // Add a one to val, then shift it left
//        if(state == true)
//            val += 1;
//        
//        val = val<<1;
        
        state = PLIB_PORTS_PinGet(PORTS_ID_0, _SDA2_port, _SDA2_pin);
        
        ShiftLeft8(&val, state);
        
        // Clock low
        PLIB_PORTS_PinClear(PORTS_ID_0, _SCL2_port, _SCL2_pin);  
        DelayNs100(_I2C_CLOCK_CYCLES_L);
    }
    
    // Send ACK or NACK on 9th Clock Cycle
    // ACK is SDA low
    if(sendACK)
        PLIB_PORTS_PinClear(PORTS_ID_0, _SDA2_port, _SDA2_pin);   // ACK
    else
        PLIB_PORTS_PinSet(PORTS_ID_0, _SDA2_port, _SDA2_pin);     // NACK
    
    // Cycle Clock
        DelayNs100(_I2C_200NS_CYCLES);
        PLIB_PORTS_PinSet(PORTS_ID_0, _SCL2_port, _SCL2_pin);  
        DelayNs100(_I2C_CLOCK_CYCLES_H);
        PLIB_PORTS_PinClear(PORTS_ID_0, _SCL2_port, _SCL2_pin);  
        DelayNs100(_I2C_CLOCK_CYCLES_L);
        
        // Finally - release SDA
        PLIB_PORTS_PinSet(PORTS_ID_0, _SDA2_port, _SDA2_pin);  
    return val;
}