/* YATC - Yet Another Thermal Camera Project 
 * 
 * Written By: Steven C. Hageman 12/2018
 *
 * Released under the: "Do whatever you want with it" license.
 * 
 * Remember the code was written by a raving lunatic and is therefore
 * certain to contain deadly bugs, errors and omissions. 
 * USE AT YOUR OWN RISK - You have been warned.
 *
 * Portions may be copyrighted by other individuals or entities.
 * See each specific code file for that information.
 * 
 * G'Day.....
 *
 */




//=====[ EXTERN_Variables.c ]===================================================

// Application 'Global or Extern Variables'

#include "app.h"


//=====[ Global Variables ]======================================================
float PixelTempArray[768];   // Temperature array populated from Melexis driver
uint16_t eeMLX90640[832];  
uint16_t mlx90640Frame[834];  
paramsMLX90640 mlx90640; 


// Pixel arrays arranged -> [row][col]
int16_t Pin[24][36];        // Pixel Array In  = Deg * SCACLE_FACTOR
int16_t Pout[116][156];     // Pixel Array Out (interpolated)) = Deg * SCALE_FACTOR


// Starting values to room temp with a call to AveragigReset())
int16_t AvgMaxValue = 0;     // Minimum Temp * SCALE_FACTOR
int16_t AvgMinValue = 0;     // Minimum Temp * SCALE_FACTOR
int16_t AvgCenValue = 3;     // Center Spot* SCALE_FACTOR


// User Interface
int16_t ColorMapToUse = 0;
CONTRAST_t ContrastCurve = NORMAL;  // 0 = Normal, 1 = High, -1 = Low


