/* YATC - Yet Another Thermal Camera Project 
 * 
 * Written By: Steven C. Hageman 12/2018
 *
 * Released under the: "Do whatever you want with it" license.
 * 
 * Remember the code was written by a raving lunatic and is therefore
 * certain to contain deadly bugs, errors and omissions. 
 * USE AT YOUR OWN RISK - You have been warned.
 *
 * Portions may be copyrighted by other individuals or entities.
 * See each specific code file for that information.
 * 
 * G'Day.....
 *
 */

#include <stdint.h>


// Fix compiler warnings
extern uint32_t SYS_CLK_SystemFrequencyGet ( void );


//=====[ Delay (Blocking) Using Core Timer ]=========================

// Prototypes,
// void DelayMs(uint32_t msDelay );
// void DelayUs(uint32_t usDelay );
// void DelayNs100(uint32_t nsDelay100 );
// void DelayCoreCycles(uint32_t clocks);


// Clock private variables
// With a default setting for a 200 MHz clock.
static uint32_t _us_Scale= 100;  
static uint32_t _ms_Scale = 100000;
static uint32_t _ns_Scale100 = 10;


// Local round closest
// Rounds integer division to the closest value
// This version only works for uints
static uint32_t divRoundClosest(uint32_t num, uint32_t denom)
{
  return ((num + (denom /(uint32_t)2)) / denom);
}



// The heart of the timer delays - reads the core times (forced inline)
static inline uint32_t __attribute__((always_inline)) ReadCoreTimer()
{
    volatile uint32_t timer;

    // place the core_timer register value in timer
    asm volatile("mfc0   %0, $9" : "=r"(timer));

    return(timer);
}


/******************************************************************************
* Function : DelayInit()
*//** 
* \b Description:
*
* Inits the timer delay constants.
* Actually reads the system clock speed to determine the delay constants.
* Needs to be called at the start of the program or if the program speed 
* changes on the fly.
*
* PRE-CONDITION: None
*
* POST-CONDITION: The time delays will be accurate.
*
* @return 		void
*
* \b Example Example:
* @code
* 	DelayInit();
* @endcode
*
* @see nothing
*******************************************************************************/
void DelayInit()
{
    // System function: SYS_CLK_SystemFrequencyGet() - See Harmony Help.
    // Returns the system clock frequency in Hz as a uint32
    
    // Bound nSec Scale and bound so that it is at least one count!
    _ns_Scale100 = divRoundClosest(SYS_CLK_SystemFrequencyGet(), 20000000UL);
    if(_ns_Scale100 == 0UL)
    {
        _ns_Scale100 = 1UL;
    }
    
    _us_Scale = divRoundClosest(SYS_CLK_SystemFrequencyGet(), 2000000UL);
    _ms_Scale = divRoundClosest(SYS_CLK_SystemFrequencyGet(), 2000UL);
    
}

 
/******************************************************************************
* Function : DelayMs(uint32_t msDelay)
*//** 
* \b Description:
*
* Provides a blocking millisecond delay using the core timer.
*
* PRE-CONDITION: Must have called DelayInit() before use.
*
* POST-CONDITION: none
*
* @return 		void
*
* \b Example Example:
* @code
*   Provide a 125 millisecond delay
* 	DelayMs(125);
* @endcode
*
* @see DelayInit()
*******************************************************************************/
void DelayMs(uint32_t msDelay)
{
      register unsigned int startCount = ReadCoreTimer();
      register unsigned int waitCount = msDelay * _ms_Scale;
 
      while( (ReadCoreTimer() - startCount) < waitCount );
}


/******************************************************************************
* Function : DelayUs(uint32_t usDelay)
*//** 
* \b Description:
*
* Provides a blocking microsecond delay using the core timer.
*
* PRE-CONDITION: Must have called DelayInit() before use.
*
* POST-CONDITION: none
*
* @return 		void
*
* \b Example Example:
* @code
*   Provide a 1250 microsecond delay
* 	DelayUs(1250);
* @endcode
*
* @see DelayInit()
*******************************************************************************/
void DelayUs(uint32_t usDelay )
{
      register unsigned int startCount = ReadCoreTimer();
      register unsigned int waitCount = usDelay * _us_Scale;
 
      while( (ReadCoreTimer() - startCount) < waitCount );
}


/******************************************************************************
* Function : DelayNs100(uint32_t nsDelay100)
*//** 
* \b Description:
*
* Provides a blocking nanosecond delay using the core timer.
* 
*  NOTE: Delay is in 100 nS intervals.
*  NOTE: For clocks 100 - 252 MHz the calculated error is < 10%
*        For clocks from 50 - 100 MHz the calculated error is < 20%
*        For clocks from 10 - 50 MHz the calculated error is < 35%
*        Do not use at clocks < 20 MHz (1 tic = 100 nS)
* 
* PRE-CONDITION: Must have called DelayInit() before use.
*
* POST-CONDITION: none
*
* @return 		void
*
* \b Example Example:
* @code
*   Provide a 600 nanosecond delay
* 	DelayNs100(6);
* @endcode
*
* @see DelayInit()
*******************************************************************************/
void DelayNs100(uint32_t nsDelay100 )
{
      register unsigned int startCount = ReadCoreTimer();
      register unsigned int waitCount = nsDelay100 * _ns_Scale100;
 
      while( (ReadCoreTimer() - startCount) < waitCount );
}


/***********************************************************
 * Delays the specified number of raw / unscaled Core Timer Cycles
 * At 252 MHz CPU Clk, Each count = 7.94 nS, Since Core Timer = 126 MHz
 */
 
/******************************************************************************
* Function : DelayCoreCycles(uint32_t delay)
*//** 
* \b Description:
*
* Provides a blocking delay using the core timer.
* Note: Delay is in raw / unscaled core timer tic's
* At 252 MHz CPU Clk, Each count = 7.94 nS, Since Core Timer = 126 MHz
* 
* PRE-CONDITION: none
*
* POST-CONDITION: none
*
* @return 		void
*
* \b Example Example:
* @code
*   Wait 125 core cycles
* 	DelayCoreCycles(125);
* @endcode
*
* @see Nothing
*******************************************************************************/
inline void __attribute__((always_inline)) DelayCoreCycles(uint32_t delay)
{
      uint32_t startCount = ReadCoreTimer();
      uint32_t waitCount = delay;
 
      while( (ReadCoreTimer() - startCount) < waitCount );
}


