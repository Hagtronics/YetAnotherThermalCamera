// Modified by Steve Hageman - See original source for the original code base.

//#include "plib.h"
//#include "peripheral/spi/plib_spi.h"
#include "peripheral/ports/plib_ports.h"
//#include "peripheral/ports/processor/ports_p32mz2048efh100.h"

/***************************************************
  This is an Arduino Library for the Adafruit 2.2" SPI display.
  This library works with the Adafruit 2.2" TFT Breakout w/SD card
  ----> http://www.adafruit.com/products/1480

  Check out the links above for our tutorials and wiring diagrams
  These displays use SPI to communicate, 4 or 5 pins are required to
  interface (RST is optional)
  Adafruit invests time and resources providing this open source code,
  please support Adafruit and open-source hardware by purchasing
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.
  MIT license, all text above must be included in any redistribution
 ****************************************************/

//
//void tft_drawLine(short x0, short y0, short x1, short y1, unsigned short color);
//void tft_drawRect(short x, short y, short w, short h, unsigned short color);
//
//void tft_drawCircle(short x0, short y0, short r, unsigned short color);
//void tft_drawCircleHelper(short x0, short y0, short r, unsigned char cornername,
//      unsigned short color);
//void tft_fillCircle(short x0, short y0, short r, unsigned short color);
//void tft_fillCircleHelper(short x0, short y0, short r, unsigned char cornername,
//      short delta, unsigned short color);
//void tft_drawTriangle(short x0, short y0, short x1, short y1,
//      short x2, short y2, unsigned short color);
//void tft_fillTriangle(short x0, short y0, short x1, short y1,
//      short x2, short y2, unsigned short color);
//void tft_drawRoundRect(short x0, short y0, short w, short h,
//      short radius, unsigned short color);
//void tft_fillRoundRect(short x0, short y0, short w, short h, short radius, unsigned short color);
//void tft_drawBitmap(short x, short y, const unsigned char *bitmap, short w, short h, unsigned short color);
//void tft_drawChar(short x, short y, unsigned char c, unsigned short color, unsigned short bg, unsigned char size);
//void tft_setCursor(short x, short y);
//void tft_setTextColor(unsigned short c);
//void tft_setTextColor2(unsigned short c, unsigned short bg);
//void tft_setTextSize(unsigned char s);
//void tft_setTextWrap(char w);
//void tft_gfx_setRotation(unsigned char r);
//void tft_write(unsigned char c);
//void tft_writeString(char* str);    // This is the function to use to write a string